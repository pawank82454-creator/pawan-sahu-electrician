# Pawan Sahu Electrician — Android project (no owner photo)

This project is for the Android app named **Pawan Sahu Electrician**.

- Service area: Chapra, Bihar
- Phone / WhatsApp booking: 9153080601
- Customer form: name, mobile, service, address, date and details
- Booking opens WhatsApp with a pre-filled message; the customer must tap Send.
- This project intentionally has no owner photo.

## Build an installable APK using only your Android phone

This ZIP is source code, not an APK. It must be built in the cloud first.

1. Open github.com in Chrome and sign in (or create a GitHub account).
2. Create a new repository. Set it to Private if you prefer.
3. Extract this ZIP using your phone's Files app.
4. Upload all extracted files and folders to the repository. Make sure the hidden `.github/workflows/build-apk.yml` file is included. If the GitHub mobile upload page hides hidden folders, use Chrome's Desktop site option or GitHub's web upload on desktop mode.
5. In the repository, open **Actions**.
6. Select **Build Android APK**, then tap **Run workflow**.
7. Wait for the workflow to finish successfully.
8. Open that completed run, find **Artifacts**, and download `Pawan-Sahu-Electrician-APK`.
9. Extract the artifact ZIP. Tap `app-debug.apk` to install it on your Motorola G85 5G. Android may ask you to allow installation from that source; only proceed if this is the build you requested and trust.

No APK binary is included yet. It is generated only after the GitHub Actions build succeeds. WhatsApp booking is not silently sent; the customer must press Send in WhatsApp.
